import express from 'express'
import * as authorsServices from '../services/authorsServices'

const router = express.Router()

router.get('/', (_req, res) => {
    res.send(authorsServices.getEntries())
})

router.get('/:id', (req, res) => {
    const author = authorsServices.findById(+req.params.id)
    res.send(author?.id ? author : 'Not found')
})

router.post('/', (_req, res) => {
    res.send('Saving a new entry article')
})

export default router