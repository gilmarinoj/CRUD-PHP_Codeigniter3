import express from 'express'
import * as sectionsServices from '../services/sectionsServices'

const router = express.Router()

router.get('/', (_req, res) => {
    res.send(sectionsServices.getEntries())
})

router.get('/:id', (req, res) => {
    const section = sectionsServices.findById(+req.params.id)
    res.send(section?.id ? section : 'Not found')
})

router.post('/', (_req, res) => {
    res.send('Saving a new entry article')
})

export default router