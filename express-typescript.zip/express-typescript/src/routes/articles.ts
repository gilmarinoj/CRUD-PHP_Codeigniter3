import express from 'express'
import * as articlesServices from '../services/articlesServices'
import toNewArticleEntry from '../utils'

const router = express.Router()

router.get('/', (_req, res) => {
    res.send(articlesServices.getEntries())
})

router.get('/:id', (req, res) => {
    const article = articlesServices.findById(+req.params.id)
    res.send(article?.id ? article : 'Not found')
})

router.post('/', (req, res) => {
    try {

        const newArticleEntry = toNewArticleEntry(req.body)

        const addedArticleEntry = articlesServices.addArticles(newArticleEntry);
    
        res.json(addedArticleEntry);
    } catch (e: any) {
        res.status(400).send(e.message)
    }

});

export default router