import { NewArticleEntry, idAuthor, idCategory } from './types';


const isString = (string: string): boolean => {
    return typeof string === 'string'
}

const isDate = (date: string): boolean => {
    return Boolean(Date.parse(date))
}



const parseTitle = (titleFromRequest: any): string => {
    if(!isString(titleFromRequest)) {
        throw new Error('Incorrect or missing title')
    }
    return titleFromRequest
}

const parseDate = (dateFromRequest: any): string => {
    if(!isString(dateFromRequest) || !isDate(dateFromRequest)) {
        throw new Error('Incorrect or missing date')
    }
    return dateFromRequest
}

const parseContent = (contentFromRequest: any): string => {
    if(!isString(contentFromRequest)) {
        throw new Error('Incorrect or missing content')
    }``
    return contentFromRequest
}

const parseAuthor = (authorFromRequest: any): idAuthor => {
    if(!isString(authorFromRequest)) {
        throw new Error('Incorrect or missing author')
    }
    return authorFromRequest
}

const parseCategory = (categoryFromRequest: any): idCategory => {
    if(!isString(categoryFromRequest)) {
        throw new Error('Incorrect or missing category')
    }
    return categoryFromRequest
}


const toNewArticleEntry = ( object: any ): NewArticleEntry => {
    const newEntry: NewArticleEntry = {
        title: parseTitle(object.title),
        date_publication: parseDate(object.date_publication),
        content: parseContent(object.content),
        id_author: parseAuthor(object.id_author),
        id_category: parseCategory(object.id_category)


    }
    return newEntry
}

export default toNewArticleEntry