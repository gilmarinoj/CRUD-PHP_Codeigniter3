import { ArticleEntry, NewArticleEntry } from '../types'
import articlesData from './articles.json'


export const articles: ArticleEntry[] = articlesData as ArticleEntry[]

export const getEntries = (): ArticleEntry[] => articles

export const findById = (id:number): ArticleEntry | undefined => {
    const entry = articles.find(article => article.id === id)
    return entry
}

export const addArticles = (newArticleEntry: NewArticleEntry): ArticleEntry => {
    const newArticle = {
        ...newArticleEntry,
        id: Math.max(...articles.map(article => article.id)) + 1
    }
    articles.push(newArticle)
    return newArticle
};