import { SectionEntry } from '../types'
import sectionsData from './sections.json'

const sections: SectionEntry[] = sectionsData as SectionEntry[]

export const getEntries = (): SectionEntry[] => sections

export const findById = (id: number): SectionEntry | undefined => {
    const entry = sections.find(section => section.id === id)
    return entry
}

export const addEntry = (): undefined => undefined