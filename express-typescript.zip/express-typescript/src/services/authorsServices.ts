import authorsData from './authors.json'
import { AuthorEntry } from '../types';

const authors: AuthorEntry[] = authorsData as AuthorEntry[]

export const getEntries = (): AuthorEntry[] => authors

export const findById = (id:number): AuthorEntry | undefined => {
    const entry = authors.find(author => author.id === id)
    return entry
}

export const addEntry = (): undefined => undefined