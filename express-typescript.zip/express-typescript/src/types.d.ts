export type idAuthor = 1 | 2 | 3 | 4 | 5;
export type idCategory = 1 | 2 | 3 | 4 | 5;



export interface ArticleEntry {
    id: number;
    title: string;
    date_publication: string;
    content: string;
    id_author: idAuthor;
    id_category: idCategory;
}

export interface AuthorEntry {
    id: number;
    name: string;
    biography: string;
    email: string;
}

export interface SectionEntry {
    id: number;
    name: string;
    description: string;
}

export type NewArticleEntry = Omit<ArticleEntry, 'id'>