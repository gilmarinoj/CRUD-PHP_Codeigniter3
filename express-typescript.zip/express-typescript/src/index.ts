import express from 'express' //ESModules
import articles from './routes/articles'
import authors from './routes/authors'
import sections from './routes/sections'


const app = express()
app.use(express.json()) //Middleware que transforma la req.body a json

const PORT = 3000

app.get('/ping', (_req, res) => {
    console.log('ping');
    res.send('pong')
})

app.use('/api/articles', articles)
app.use('/api/authors', authors)
app.use('/api/sections', sections)

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
})