import { Server } from './presentation/server'

( async () => {
    main()
})()

function main(){

    // Levantar base de datos


    // Levantar servidor
    const server = new Server()
    server.start()

}
