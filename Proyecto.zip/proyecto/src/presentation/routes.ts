import { Router } from "express";
import { ArticlesRoutes } from "./articles/routes";

export class AppRoutes{

    static get route(): Router{
        const routes = Router();

        routes.use('api/articles', ArticlesRoutes.route)

        return routes;
    }
}