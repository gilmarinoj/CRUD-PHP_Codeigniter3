import { Request, Response } from "express"

export class ArticlesController{
    
    create = ( req: Request, res: Response ) => {
        return res.json({message: 'Article Create'})
    };
    
    update = ( req: Request, res: Response ) => {
        return res.json({message: 'Article Updated'})
    };

    delete = ( req: Request, res: Response ) => {
        return res.json({message: 'Article Deleted'})
    }

    findall = ( req: Request, res: Response ) => {
        return res.json({message: 'Articles Finded'})
    }
}