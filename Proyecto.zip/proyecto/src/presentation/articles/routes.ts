import { Router } from "express";
import { ArticlesController } from './controller';

export class ArticlesRoutes{

    static get route(): Router{
        const routes = Router();
        const controller = new ArticlesController()

        routes.get('/findall', controller.findall)
        routes.put('/update', controller.update)
        routes.delete('/delete', controller.delete)
        routes.post('/create`', controller.create)

        return routes;
    }
}