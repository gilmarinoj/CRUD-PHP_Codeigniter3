import express from 'express';
import { AppRoutes } from './routes';
export class Server {
    
    private app = express();
    start(){
        this.app.use(AppRoutes.route)
        
        this.app.listen(3000, () => {
            console.log(`Server running on port ${3000}`);

        })
    }
}