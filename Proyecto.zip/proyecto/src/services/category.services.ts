import { SectionEntry } from '../types'
import sectionsData from './category.json'

const sections: SectionEntry[] = sectionsData as SectionEntry[]

export const getEntries = (): SectionEntry[] => sections

export const findById = (id: number): SectionEntry | undefined => {
    const entry = sections.find(section => section.categoryId === id)
    return entry
}

export const addEntry = (): undefined => undefined